public class CalcFirstHundredNumbers {

    public static void main(String[] args) {
        /**
         *
         *
         */
        int a = 100;
        int s = ( a * ( a + 1 ) ) / 2;
        System.out.println(s);
    }
}
