import java.util.Scanner;

public class SquareSideArea {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter square side length");
        int side = in.nextInt();
        if (side <= 0) {
            System.out.println("Error: this number is not valid");
        }
        else {
            int area = side * 2;
            System.out.println("The area of the square is : " + area);
        }
    }
}
