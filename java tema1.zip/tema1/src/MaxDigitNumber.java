import java.util.Scanner;

public class MaxDigitNumber {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter number");
        int number = in.nextInt();
        int[] array = new int[number];
        int length = array.length;
        int max = array[0];
        for (int i = 0; i < length; i++) {
            if(array[i] > max);
            array[i] = max;
        }
        System.out.println("Max digit is " + max);
    }
}


