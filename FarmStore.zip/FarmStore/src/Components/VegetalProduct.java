package Components;

public class VegetalProduct extends Product {

    private String vitaminList;

    public VegetalProduct(int id, int stockNumber, double price, double validity, double weight, String vitaminList){
        super(id, stockNumber, price, validity, weight);
        this.vitaminList = vitaminList;
    }



    @Override
    public void createProd() {

    }

    @Override
    public void sellProd() {

    }

    @Override
    public void sellProd() {

    }

    @Override
    public void displayDailyReport() {

    }

    @Override
    private void exitOptions() {

    }
}
