package Components;

public interface CustomerOptions {

    void createProd();
    void sellProd();
    void displayDailyReport();
    void exitOptions();
}
