package BiggestNumber;

import java.util.Scanner;

public class BiggestNumber {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Input the first number: ");
        int x = in.nextInt();
        System.out.print("Input the Second number: ");
        int y = in.nextInt();
        System.out.print("Input the third number: ");
        int z = in.nextInt();
        System.out.print("The biggest value is " + getMax(x, y, z)+"\n" );
    }
    private static int getMax(int x, int y, int z) {
        return Math.max(Math.max(x, y), z);
    }
}
