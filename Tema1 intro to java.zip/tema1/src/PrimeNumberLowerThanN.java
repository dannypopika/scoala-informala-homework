import java.util.Scanner;

public class PrimeNumberLowerThanN {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter number");
        int a;
        int n = in.nextInt();
        for (a = 2; a <= n; a++) {
            if (isPrime(a))
                System.out.println(a);
        }
    }
    private static boolean isPrime(int m) {
        for (int i = 2; i < m; i++) {
            if (m % i == 0)
                return false;
        }
        return true;
    }
}
