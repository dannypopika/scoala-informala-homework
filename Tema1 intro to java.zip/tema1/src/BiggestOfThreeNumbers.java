import java.util.Scanner;

public class BiggestOfThreeNumbers {

    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the first number : ");
        int nr1 = in.nextInt();
        System.out.println("Enter the secong number: ");
        int nr2 = in.nextInt();
        System.out.println("Enter the third number: ");
        int nr3 = in.nextInt();
        if (nr1 > nr2 && nr1 > nr3)
            System.out.println("The biggest number is " + nr1);
        else if (nr2 > nr1 && nr2 > nr3)
            System.out.println("The biggest number is " + nr2);
        else if (nr3 > nr1 && nr3 > nr2)
            System.out.println("The biggest number is " + nr3);
        else
            System.out.println("The numbers are not distinct");
    }
}
