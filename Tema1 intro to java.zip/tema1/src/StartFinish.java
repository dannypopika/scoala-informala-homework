import java.util.Scanner;

public class StartFinish {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int start;
        int end;

        System.out.println("Enter 1st whole number: ");
        while (!scan.hasNextInt()) {
            System.out.println("Input must be a whole number. Try again:");
            scan.next();
        }
        start = scan.nextInt();

        System.out.println("Enter 2nd whole number: ");
        while (!scan.hasNextInt()) {
            System.out.println("Input must be a whole number. Try again:");
            scan.next();
        }
        end = scan.nextInt();
        if(start < end)
            for(int i = start; i <= end; i++)
                System.out.print(i + " ");

        else if(start > end)
            for(int i = start; i >= end; i--)
                System.out.print(i + " ");
    }
}
